@echo off
cd /d "%~dp0app"
set ASPNETCORE_ENVIRONMENT=Development
set ASPNETCORE_URLS=https://localhost:7119;http://localhost:5256
set ASPNETCORE_HTTPS_PORT=7119
dotnet LR2_Devise_RL.dll
pause
