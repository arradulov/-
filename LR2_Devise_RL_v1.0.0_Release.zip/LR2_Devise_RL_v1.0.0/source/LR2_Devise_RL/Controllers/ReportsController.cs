﻿using LR2_Devise_RL.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace LR2_Devise_RL.Controllers
{
    [ApiController]
    [Route("api/reports")]
    [Authorize]
    public class ReportsController : ControllerBase
    {
        private readonly AppDbContext _context;
        public ReportsController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet("flights")]
        public IActionResult GetFlights()
        {
            var report = _context.FlightResults
                .Join(
                    _context.Devices,
                    result => result.DeviceId,
                    device => device.Id,
                    (result, device) => new { result, device }
                )
                .Join(
                    _context.Missions,
                    flight => flight.result.MissionId,
                    mission => mission.Id,
                    (flight, mission) => new
                    {
                        Id = flight.result.Id,
                        DeviceName = flight.device.Name,
                        Name = mission.Name,
                        FlightTime = flight.result.FlightTime,
                        ActualDistance = flight.result.ActualDistance,
                        IsSuccessful = flight.result.IsSuccessful
                    }
                )
                .ToList();

            return Ok(report);
        }
        [HttpGet("successful-flights")]
        public IActionResult GetSuccessfulFlights()
        {
            var report = _context.FlightResults
                .Where(result => result.IsSuccessful)
                .Join(
                    _context.Devices,
                    result => result.DeviceId,
                    device => device.Id,
                    (result, device) => new { result, device }
                )
                .Join(
                    _context.Missions,
                    flight => flight.result.MissionId,
                    mission => mission.Id,
                    (flight, mission) => new { flight, mission }
                )
                .Select(item => new
                {
                    Id = item.flight.result.Id,
                    DeviceName = item.flight.device.Name,
                    Name = item.mission.Name,
                    FlightTime = item.flight.result.FlightTime,
                    ActualDistance = item.flight.result.ActualDistance
                })
                .ToList();

            return Ok(report);
        }
    }
}
