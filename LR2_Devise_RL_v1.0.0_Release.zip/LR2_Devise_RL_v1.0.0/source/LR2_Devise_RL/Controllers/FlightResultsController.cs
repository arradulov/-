﻿using LR2_Devise_RL.Data;
using LR2_Devise_RL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LR2_Devise_RL.Controllers
{
    [ApiController]
    [Route("api/flightresults")]
    public class FlightResultsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public FlightResultsController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public List<FlightResult> GetAll()
        {
            return _context.FlightResults.ToList();
        }
        [HttpGet("{id:int}")]
        public ActionResult<FlightResult> GetById(int id)
        {
            var flightresults = _context.FlightResults.Find(id);

            if (flightresults == null)
            {
                return NotFound();
            }

            return Ok(flightresults);
        }
        [HttpPost]
        [Authorize(Roles = "admin")]
        public ActionResult<FlightResult> Create([FromBody] FlightResult result)
        {
            if (result.FlightTime <= 0)
            {
                return BadRequest("Время полёта должно быть больше нуля.");
            }

            if (result.ActualDistance < 0)
            {
                return BadRequest("Расстояние не может быть отрицательным.");
            }

            if (_context.Devices.Find(result.DeviceId) == null)
            {
                return BadRequest("Устройство с таким ID не существует.");
            }

            if (_context.Missions.Find(result.MissionId) == null)
            {
                return BadRequest("Миссия с таким ID не существует.");
            }

            result.Id = 0;

            _context.FlightResults.Add(result);
            _context.SaveChanges();

            return CreatedAtAction(
                nameof(GetById),
                new { id = result.Id },
                result);
        }
        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            var result = _context.FlightResults.Find(id);

            if (result == null)
            {
                return NotFound();
            }

            _context.FlightResults.Remove(result);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
