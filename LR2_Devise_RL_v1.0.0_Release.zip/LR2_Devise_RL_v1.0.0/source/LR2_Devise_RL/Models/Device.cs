﻿namespace LR2_Devise_RL.Models
{
    ///Модель девайса, задает основные параметры
    public class Device
    {
        
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int BatteryLevel { get; set; }
        public double MaxSpeed { get; set; }
        public double MinSpeed { get; set; }
        public bool IsActive { get; set; } = true;

        public bool CanStartMission()
        {
            return BatteryLevel >= 20;
        }
    }
}
