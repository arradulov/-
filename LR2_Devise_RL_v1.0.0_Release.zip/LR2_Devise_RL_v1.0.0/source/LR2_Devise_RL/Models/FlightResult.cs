﻿namespace LR2_Devise_RL.Models
{
    public class FlightResult
    {
        public int Id { get; set; }
        public int DeviceId { get; set; }
        public int MissionId { get; set; }
        public double FlightTime { get; set; }
        public double ActualDistance { get; set; }
        public bool IsSuccessful { get; set; }

        public double CalculateAverageSpeed()
        {
            if (FlightTime <= 0)
            {
                throw new ArgumentException("Время полёта должно быть больше нуля.");
            }
            return ActualDistance / FlightTime;
        }
    }
}
