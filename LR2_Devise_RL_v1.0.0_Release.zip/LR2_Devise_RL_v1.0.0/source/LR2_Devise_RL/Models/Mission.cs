﻿namespace LR2_Devise_RL.Models
{
    public class Mission
    {
        public string Name { get; set; } = string.Empty;
        public int Id { get; set; }
        public double Distance { get; set; }
        public double Speed { get; set; }
        public double CalculateExpectedTime()
        {
            if (Speed <= 0)
            {
                throw new InvalidOperationException("Скорость должна быть больше нуля.");
            }
            return Distance / Speed;
        }
    }
}
